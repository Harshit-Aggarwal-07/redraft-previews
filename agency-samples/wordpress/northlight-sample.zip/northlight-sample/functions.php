<?php
// Block themes do not load style.css on the front end automatically.
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'northlight-sample', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
} );
add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'northlight-sample-editor', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
} );
