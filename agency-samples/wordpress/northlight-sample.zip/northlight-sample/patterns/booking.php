<?php
/**
 * Title: Booking form
 * Slug: northlight-sample/booking
 * Categories: featured
 * Inserter: true
 */
?>
<!-- wp:group {"align":"full","anchor":"book","className":"nl-book","backgroundColor":"brand-dark","textColor":"white","style":{"spacing":{"padding":{"top":"56px","bottom":"56px"}}},"layout":{"type":"constrained"}} -->
<div id="book" class="wp-block-group alignfull nl-book has-white-color has-brand-dark-background-color has-text-color has-background" style="padding-top:56px;padding-bottom:56px"><!-- wp:heading {"textColor":"white"} -->
<h2 class="wp-block-heading has-white-color has-text-color">Book your $49 assessment</h2>
<!-- /wp:heading -->
<!-- wp:html -->
<form class="nl-form" action="#" method="post" onsubmit="event.preventDefault();this.querySelector('[role=status]').hidden=false">
<div class="field"><label for="nl-name">Full name</label><input id="nl-name" name="name" type="text" autocomplete="name" required></div>
<div class="field"><label for="nl-phone">Mobile number</label><input id="nl-phone" name="phone" type="tel" autocomplete="tel" required></div>
<div class="field"><label for="nl-area">Where does it hurt?</label><select id="nl-area" name="area"><option>Lower back</option><option>Neck and shoulders</option><option>Knee</option><option>Other</option></select></div>
<button type="submit">Request my booking</button>
<p class="nl-demo-note">Demo form: does not send anything. A real build would replace this block with the agency's form plugin (Contact Form 7, Gravity Forms, WPForms, etc.).</p>
<p role="status" hidden>Demo only: nothing was sent.</p>
</form>
<!-- /wp:html --></div>
<!-- /wp:group -->
