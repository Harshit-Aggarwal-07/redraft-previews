<?php
/**
 * Title: Pricing
 * Slug: northlight-sample/pricing
 * Categories: featured
 * Inserter: true
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"56px","bottom":"56px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:56px;padding-bottom:56px"><!-- wp:heading -->
<h2 class="wp-block-heading">Simple, upfront pricing</h2>
<!-- /wp:heading -->
<!-- wp:columns -->
<div class="wp-block-columns">
<!-- wp:column {"className":"nl-plan nl-plan-featured","style":{"spacing":{"padding":{"top":"26px","bottom":"26px","left":"26px","right":"26px"}}}} -->
<div class="wp-block-column nl-plan nl-plan-featured" style="padding-top:26px;padding-right:26px;padding-bottom:26px;padding-left:26px"><!-- wp:paragraph {"className":"nl-flag"} -->
<p class="nl-flag">New patients</p>
<!-- /wp:paragraph --><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">First assessment</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"nl-price"} -->
<p class="nl-price">$49 <small>one-off</small></p>
<!-- /wp:paragraph -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>45-minute one-on-one assessment</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Written treatment plan</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>First treatment included</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"href":"#book"} -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#book">Book this offer</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->
<!-- wp:column {"className":"nl-plan ","style":{"spacing":{"padding":{"top":"26px","bottom":"26px","left":"26px","right":"26px"}}}} -->
<div class="wp-block-column nl-plan " style="padding-top:26px;padding-right:26px;padding-bottom:26px;padding-left:26px"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Follow-up session</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"nl-price"} -->
<p class="nl-price">$85 <small>per 30 minutes</small></p>
<!-- /wp:paragraph -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Hands-on treatment</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Exercise progression</li>
<!-- /wp:list-item --><!-- wp:list-item -->
<li>Progress check against your plan</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"href":"#book"} -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#book">Book a follow-up</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size">Prices are fictional placeholders.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
