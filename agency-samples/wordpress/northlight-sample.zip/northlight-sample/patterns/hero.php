<?php
/**
 * Title: Hero
 * Slug: northlight-sample/hero
 * Categories: featured
 * Inserter: true
 */
?>
<!-- wp:cover {"align":"full","overlayColor":"brand-dark","isUserOverlayColor":true,"minHeight":0,"className":"nl-hero","layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull nl-hero"><span aria-hidden="true" class="wp-block-cover__background has-brand-dark-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"className":"nl-eyebrow"} -->
<p class="nl-eyebrow">New-patient offer</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"textColor":"white"} -->
<h1 class="wp-block-heading has-white-color has-text-color">Back pain holding you back? Get moving again.</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"nl-lead","textColor":"white"} -->
<p class="nl-lead has-white-color has-text-color">Your first assessment and treatment plan for a flat $49, with a physio who explains what is going on and what to do next.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"accent","textColor":"ink","href":"#book"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-ink-color has-accent-background-color has-text-color has-background wp-element-button" href="#book">Book my $49 assessment</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
<!-- wp:paragraph {"textColor":"white","fontSize":"small"} -->
<p class="has-white-color has-text-color has-small-font-size">Fictional offer. Sample content only.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->
