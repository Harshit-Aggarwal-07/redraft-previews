<?php
/**
 * Title: Testimonials
 * Slug: northlight-sample/testimonials
 * Categories: featured
 * Inserter: true
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"tint","style":{"spacing":{"padding":{"top":"56px","bottom":"56px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-tint-background-color has-background" style="padding-top:56px;padding-bottom:56px"><!-- wp:heading -->
<h2 class="wp-block-heading">What patients say</h2>
<!-- /wp:heading -->
<!-- wp:columns -->
<div class="wp-block-columns">
<!-- wp:column {"backgroundColor":"white","className":"nl-card nl-quote-card","style":{"spacing":{"padding":{"top":"22px","bottom":"22px","left":"22px","right":"22px"}}}} -->
<div class="wp-block-column nl-card nl-quote-card has-white-background-color has-background" style="padding-top:22px;padding-right:22px;padding-bottom:22px;padding-left:22px"><!-- wp:paragraph {"className":"nl-tag"} -->
<p class="nl-tag">Placeholder testimonial</p>
<!-- /wp:paragraph -->
<!-- wp:quote -->
<blockquote class="wp-block-quote"><!-- wp:paragraph -->
<p>“Short quote about getting an appointment quickly goes here.”</p>
<!-- /wp:paragraph --><cite>Client name, suburb</cite></blockquote>
<!-- /wp:quote --></div>
<!-- /wp:column -->
<!-- wp:column {"backgroundColor":"white","className":"nl-card nl-quote-card","style":{"spacing":{"padding":{"top":"22px","bottom":"22px","left":"22px","right":"22px"}}}} -->
<div class="wp-block-column nl-card nl-quote-card has-white-background-color has-background" style="padding-top:22px;padding-right:22px;padding-bottom:22px;padding-left:22px"><!-- wp:paragraph {"className":"nl-tag"} -->
<p class="nl-tag">Placeholder testimonial</p>
<!-- /wp:paragraph -->
<!-- wp:quote -->
<blockquote class="wp-block-quote"><!-- wp:paragraph -->
<p>“Short quote about the clear treatment plan goes here.”</p>
<!-- /wp:paragraph --><cite>Client name, suburb</cite></blockquote>
<!-- /wp:quote --></div>
<!-- /wp:column -->
<!-- wp:column {"backgroundColor":"white","className":"nl-card nl-quote-card","style":{"spacing":{"padding":{"top":"22px","bottom":"22px","left":"22px","right":"22px"}}}} -->
<div class="wp-block-column nl-card nl-quote-card has-white-background-color has-background" style="padding-top:22px;padding-right:22px;padding-bottom:22px;padding-left:22px"><!-- wp:paragraph {"className":"nl-tag"} -->
<p class="nl-tag">Placeholder testimonial</p>
<!-- /wp:paragraph -->
<!-- wp:quote -->
<blockquote class="wp-block-quote"><!-- wp:paragraph -->
<p>“Short quote about being back to normal activity goes here.”</p>
<!-- /wp:paragraph --><cite>Client name, suburb</cite></blockquote>
<!-- /wp:quote --></div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
