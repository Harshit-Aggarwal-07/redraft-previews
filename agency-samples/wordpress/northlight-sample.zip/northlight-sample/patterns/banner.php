<?php
/**
 * Title: Sample notice
 * Slug: northlight-sample/banner
 * Categories: featured
 * Inserter: true
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"sample-yellow","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-sample-yellow-background-color has-background"><!-- wp:paragraph {"align":"center","className":"nl-banner","textColor":"ink"} -->
<p class="has-text-align-center nl-banner has-ink-color has-text-color">Sample build for a fictional business, for agency partners. Delete this notice before launch.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
