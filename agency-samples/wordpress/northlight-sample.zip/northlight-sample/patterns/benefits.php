<?php
/**
 * Title: Benefits
 * Slug: northlight-sample/benefits
 * Categories: featured
 * Inserter: true
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"56px","bottom":"56px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:56px;padding-bottom:56px"><!-- wp:heading -->
<h2 class="wp-block-heading">Why people choose Northlight</h2>
<!-- /wp:heading -->
<!-- wp:columns -->
<div class="wp-block-columns">
<!-- wp:column {"backgroundColor":"tint","className":"nl-card","style":{"spacing":{"padding":{"top":"24px","bottom":"24px","left":"24px","right":"24px"}}}} -->
<div class="wp-block-column nl-card has-tint-background-color has-background" style="padding-top:24px;padding-right:24px;padding-bottom:24px;padding-left:24px"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Seen within 48 hours</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">Most new patients get an appointment within two working days.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column {"backgroundColor":"tint","className":"nl-card","style":{"spacing":{"padding":{"top":"24px","bottom":"24px","left":"24px","right":"24px"}}}} -->
<div class="wp-block-column nl-card has-tint-background-color has-background" style="padding-top:24px;padding-right:24px;padding-bottom:24px;padding-left:24px"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">A clear plan, not guesswork</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">You leave with a written plan: what to do, how often, and what to expect.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column {"backgroundColor":"tint","className":"nl-card","style":{"spacing":{"padding":{"top":"24px","bottom":"24px","left":"24px","right":"24px"}}}} -->
<div class="wp-block-column nl-card has-tint-background-color has-background" style="padding-top:24px;padding-right:24px;padding-bottom:24px;padding-left:24px"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">One physio, start to finish</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">The same person looks after you at every visit.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
