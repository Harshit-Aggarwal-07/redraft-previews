<?php
/**
 * Title: FAQ
 * Slug: northlight-sample/faq
 * Categories: featured
 * Inserter: true
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"tint","style":{"spacing":{"padding":{"top":"56px","bottom":"56px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-tint-background-color has-background" style="padding-top:56px;padding-bottom:56px"><!-- wp:heading -->
<h2 class="wp-block-heading">Questions, answered</h2>
<!-- /wp:heading -->
<!-- wp:details -->
<details class="wp-block-details"><summary>Do I need a referral?</summary><!-- wp:paragraph {"placeholder":"Type / to add a hidden block"} -->
<p>No. You can book directly. (Sample answer.)</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>Can I claim on private health cover?</summary><!-- wp:paragraph {"placeholder":"Type / to add a hidden block"} -->
<p>Many funds cover physio. Bring your card and we will help you check. (Sample answer.)</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>What should I wear?</summary><!-- wp:paragraph {"placeholder":"Type / to add a hidden block"} -->
<p>Comfortable clothes you can move in.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>What if I need to reschedule?</summary><!-- wp:paragraph {"placeholder":"Type / to add a hidden block"} -->
<p>Let us know 24 hours ahead and there is no fee. (Sample policy.)</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->
</div>
<!-- /wp:group -->
