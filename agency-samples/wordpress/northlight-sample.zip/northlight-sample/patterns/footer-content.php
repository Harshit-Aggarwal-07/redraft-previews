<?php
/**
 * Title: Footer content
 * Slug: northlight-sample/footer-content
 * Categories: featured
 * Inserter: false
 */
?>
<!-- wp:group {"align":"full","className":"nl-footer","backgroundColor":"footer","textColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull nl-footer has-white-color has-footer-background-color has-text-color has-background"><!-- wp:paragraph -->
<p><strong>Northlight Physio</strong> is a fictional clinic used as a sample. It does not exist.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Fictional address and phone intentionally omitted. Privacy and terms links would go here.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
